    <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2017-2018 <a href="#" style="color: black">My India Kart</a>.</strong> All rights reserved.
      </footer>
