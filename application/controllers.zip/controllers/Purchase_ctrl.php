<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_ctrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set("Asia/Kolkata");
		$this->load->model('Settings_model');

		$this->load->model('basic');
			if(!$this->session->userdata('logged_in_adminw1')) { 
			redirect(base_url());
		}
	}
	
	public function index()
	{

		 $template['page'] = 'Purchase/view_purchase';
		 $template['title'] = 'Purchase Orders';
		 $join = array('{PRE}vendor'=>'{PRE}purchase.vendor_id = {PRE}vendor.vendor_id,inner');
		 $template['data'] =$this->basic->get_data('{PRE}purchase','','*',$join);
		 //print_r(json_encode($template)); die;

		 $this->load->view('template',$template);
	}
	public function add_new_purchase_order()
	{
	     $template['page'] = 'Purchase/add_new_purchase';
		 $template['title'] = 'Purchase Orders';
		 $template['products'] =$this->basic->get_data('{PRE}products','','*');
		 $template['vendor'] =$this->basic->get_data('{PRE}vendor','','*');
		 if($_POST)
		 {
		 	 $temp_data2['payable_amount'] = 0;
		     $data = $this->basic->get_post_data();
		     
		     //print_r(json_encode($data)); die;
		     $data1= array_slice($data,2);
			 $temp_data['vendor_id'] = $data['vendor_id'];
			 $temp_data['date'] = date('Y-m-d');
			 $temp_data['payment_status'] = $data['payment_method'];
			 $purchase_id = $this->basic->insert_data_id('{PRE}purchase',$temp_data);
			 //$temp_data['total_products'] = $data['option_counts']-1;
			 //print_r($purchase_id); die;

			$temp_data3=$temp_data;
			$temp_data = array();
			$temp_data3['payable_amount']=0;
		     for($i = 1; $i < $data['option_counts'];++$i)
		     {
		       	$temp_data['purchase_id'] = $purchase_id;
		        $temp_data['product_id'] = $data['item_id'.$i];
		        $temp_data['cost'] = $data['cost'.$i];
		        $temp_data['selling_price']= $data['selling_price'.$i];
		        $temp_data['quantity'] = $data['quantity'.$i];
		       	$temp_data3['payable_amount'] =$temp_data3['payable_amount'] + ($temp_data['quantity']*$temp_data['cost']);
		        $this->basic->insert_data('{PRE}purchase_details',$temp_data);
		        $cost_price_data['product_id']	= $temp_data['product_id'];
		        $cost_price_data['selling_price'] =	$temp_data['selling_price'];
		        $cost_price_data['purchase_price'] =	$temp_data['cost'];
		        $this->basic->set_update_cost_and_selling_price('{PRE}product_price',$cost_price_data);
		     }
		    
		   
		     if($data['payment_method']==0)
		     {
		     	$this->basic->update_data('{PRE}purchase',array('purchase_id'=>$purchase_id),$temp_data3);
		     }
		     else
		     {
		     	$temp_data3['paid_amount'] = $temp_data3['payable_amount'];
		     	$this->basic->update_data('{PRE}purchase',array('purchase_id'=>$purchase_id),$temp_data3);
		     	$paid_table['purchase_id'] = $purchase_id;
		     	$paid_table['date'] = date('Y-m-d');
		     	$paid_table['vendor_id'] = $data['vendor_id'];
		     	$paid_table['paid_amount'] = $temp_data3['payable_amount'];
		     	$this->basic->insert_data('{PRE}paid',$paid_table);
		     }
		    
		
		     $inventory_data=array();
		     $inventory_data['type']=0;
		     $inventory_data['purchase_id']= $temp_data['purchase_id'];
		     $this->basic->insert_data('{PRE}inventory',$inventory_data);
		     $debt_data=array();
		     $debt_data['date'] = date('Y-m-d');
		     $debt_data['vendor_id']= $data['vendor_id'];
		     $debt_data['payable']= $temp_data3['payable_amount'];
		     $debt_data['purchase_id'] = $purchase_id;

		     if($data['payment_method']==0)
		     {
		     	//credit
		     	//$debt_data['payable']= $debt_data['total_amount'];
		     }
		     else
		     {
			     	//cash
		     	$debt_data['paid']= $debt_data['payable'];
		     }
		     $this->basic->insert_data('{PRE}debts',$debt_data);
		     $this->session->set_flashdata('message', array('message'=>"Added Succussfully",'class' => 'success'));
		  		redirect('Purchase_ctrl/', 'refresh');
		 }
		 $this->load->view('template',$template);
	}

	public function add_vendor_popup()
	{
	    $this->load->view('Purchase/add_vendor_popup');
	}
	public function add_vendor()
	{
		     $data = $this->basic->get_post_data();
		     $data['vendor_id'] = $this->basic->insert_data_id('{PRE}vendor',$data);
		     print_r(json_encode($data));
	}
	public function paid_payment()
	{
		$template['page'] = 'Purchase/view_paid';
		$template['title'] = 'Paid Amount';
		$join = array('{PRE}vendor'=>'{PRE}paid.vendor_id = {PRE}vendor.vendor_id,inner');
		$template['data'] = $this->basic->get_data('{PRE}paid', '', '{PRE}paid.*,{PRE}vendor.*', $join);
		
//		print_r(json_encode($template['data'])); die;
		$this->load->view('template',$template);
	}
	public function add_new_payment()
	{
		$template['page'] = 'Purchase/add_paid';
		$template['title'] = 'Add Payment';
	 	$template['data'] = $this->basic->get_data('{PRE}vendor', '', '{PRE}vendor.vendor_id,{PRE}vendor.vendor_name');
		if($_POST)
		{
		    $data = $this->basic->get_post_data();
		    $data_temp['vendor_id']=$data['client_id'];
			$data_temp['date'] = date('Y-m-d');		    
			$data_temp['paid_amount'] = $data['received'];
			$data_temp['payable_f']=-1;
			
		    $insert_id = $this->basic->insert_data_id('{PRE}paid',$data_temp);
		    $this->session->set_flashdata('message', array('message'=>"Added Succussfully",'class' => 'success'));
		  		redirect('Purchase_ctrl/', 'refresh');
		}
		$this->load->view('template', $template);
	}
	public function get_vendor_details()
	{
		$res=$this->input->post('id');
		$where=array('vendor_id'=>$res);
		$template['shipping_details'] = $this->basic->get_data('{PRE}vendor', $where, '*');
		$where=array('vendor_id'=>$res);
		$template['total_purchase']= $this->basic->get_sum_of_sales('{PRE}purchase', $where, 'payable_amount');
		$template['total_paid']= $this->basic->get_sum_of_sales('{PRE}paid', $where, 'paid_amount');
		print_r(json_encode($template)); 
	}
	public function view_invoice($purchase_id, $vendor_id, $payment_status)
	{

		$where['where']=array('vendor_id'=>$vendor_id);
		$template['shipping_details'] = $this->basic->get_data('{PRE}vendor', $where, '*');
		$template['invoice_id'] = 123;
		$template['products']= $this->basic->join_for_purchase_data($purchase_id, $vendor_id);
		$template['logo'] = $this->Settings_model->settings_viewings();
		$template['payment_type']=$payment_status;
		$where1=array('vendor_id' => $vendor_id);
		$total_amount = $this->basic->get_sum_of_sales('{PRE}purchase', $where1, 'payable_amount');// - $this->basic->get_sum('{PRE}sales', $where);
		$where2=array('vendor_id' => $vendor_id);
		$received_amount = $this->basic->get_sum_of_sales('{PRE}paid', $where2, 'paid_amount');
		$template['net_balance_to_pay']=$total_amount[0]->payable_amount-$received_amount[0]->paid_amount;	
		$this->load->view('Pdf/subs_for_sale',$template);

	}
}
?>