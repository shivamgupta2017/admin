<?php
$setting = getSettings();
?>
    <head>
        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php $setting->title; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
      <meta name="description" content="">
      <meta name="author" content="">
      
	 

    
     
	  
	  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	  <link href="<?php echo base_url();?>/assets/css/charisma-app.css" rel="stylesheet">
	    <link href="<?php echo base_url();?>/assets/css/colorbox.css" rel="stylesheet">
	  
	   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">-->
  
  
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/datepicker3.css">
	 
	  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/blue.css">
	  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-jvectormap-1.2.2.css">
	  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/_all-skins.min.css">
     <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/select2.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/AdminLTE.min.css">

	 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/alertify.core.css" />
	 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/alertify.default.css" id="toggleCSS" />
     <script src="<?php echo base_url();?>assets/js/alertify.min.js"></script>
	<!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/pace.css">
   
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom-style.css">
	
	<!--time picker-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-timepicker.min.css">
    <!--time picker-->
	    
		
		<script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>	
	<link href="<?php echo base_url();?>assets/parsley/parsley.css" rel="stylesheet">
   </head>