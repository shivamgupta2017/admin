<table class="table table-bordered" style="text-align: left">
  <tbody> 
    <td colspan="5">
      <table class="table">
        <tbody>
        <tr>
          <th>Name</th>
          <th>Company</th>
          <th>Address</th>
          <th>Phone</th>
          <th>Email</th>
        </tr>
        <?php
        if($data != NULL){
        foreach ($data as $rs) { ?>
        <tr>     
          <td><?php echo ucfirst($rs->first_name).' '.ucfirst($rs->last_name); ?></td>
          <td><?php echo $rs->company; ?></td>
          <td><?php echo $rs->address; ?></td>
          <td><?php echo $rs->phone;?></td>
           <td><?php echo $rs->email?></td>
        </tr>
        <?php 
        
        } }else{?><td>No Products In this Order</td><?php } ?>
        </tbody>
      </table>
    </td>
  </tr>
  </tbody>
</table>