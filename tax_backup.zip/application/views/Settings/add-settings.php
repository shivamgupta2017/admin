<div class="content-wrapper">
     <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="<?php echo base_url();?>assets/css/bootstrap-datetimepicker.min.css">
        <!-- Content Header (Page header) -->
        <section class="content-header">

          <h1>
            Add Setting Details
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-wrench" aria-hidden="true"></i>Home</a></li>
            <li><a href="#">Settings</a></li>
            <li class="active">Add Settings</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
			<?php
			if($this->session->flashdata('message')) {
			$message = $this->session->flashdata('message');

			?>
			<div class="alert alert-<?php echo $message['class']; ?>">
			<button class="close" data-dismiss="alert" type="button">×</button>
			<?php echo $message['message']; ?>
			</div>
			<?php
			}
			?>
			</div>
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Add Setting Details</h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                 <form role="form" action="" method="post" data-parsley-validate="" class="validate" enctype="multipart/form-data">
				 <div class="box-body">
				 <div class="col-md-6">
				 
                        
                                    <div class="form-group">
                                    <label class="intrate">Title</label>
                                    <input class="form-control required regcom" type="text" name="title" data-parsley-trigger="keyup" required="" id="smtp_username" value="<?php echo $result->title; ?>">
                                    </div>
										
								    <div class="form-group">
                                    <label class="intrate">Smtp Username</label>
                                    <input class="form-control required regcom" type="text" name="smtp_username" data-parsley-trigger="keyup" required="" id="smtp_username" value="<?php echo $result->smtp_username; ?>">
                                    </div>

                                    <div class="form-group">
                                    <label  class="intrate">Smtp Password</label>
                                    <input 	class="form-control regcom required" type="text" name="smtp_password" data-parsley-trigger="keyup" required="" id="smtp_password" value="<?php echo $result->smtp_password; ?>" >
                                    </div>									
                                    
									<div class="form-group">
                                    <label  class="intrate">Smtp Host</label>
                                    <input 	class="form-control regcom required" type="text" name="smtp_host" data-parsley-trigger="keyup" required="" id="smtp_host" value="<?php echo $result->smtp_host; ?>" >
                                    </div>
									
									
									<div class="form-group">
                                    <label  class="intrate">Admin Email</label>
                                    <input 	class="form-control regcom required" type="text" name="admin_email" data-parsley-trigger="keyup" required="" id="admin_email" value="<?php echo $result->admin_email; ?>" >
                                    </div>
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Places</label>
                                    <input 	class="form-control regcom required" type="text" name="places" data-parsley-trigger="keyup" required="" id="places" value="<?php echo $result->places; ?>" >
                                    </div> -->
									
									
									<div class="form-group">
                                    <label  class="intrate">Country</label>
                                    <input 	class="form-control regcom required" type="text" name="country" data-parsley-trigger="keyup" required="" id="country" value="<?php echo $result->country; ?>" >
                                    </div>                                    
                                    <div class="form-group">
                                    <label  class="intrate">Social Sign</label>
                                    <select id="social_sign" name="social_sign" class="form-control">
                                        <option value="0" <?php if($result->social_sign=='0'){ echo 'selected="SELECTED"'; } ?>>No</option>
                                        <option value="1" <?php if($result->social_sign=='1'){ echo 'selected="SELECTED"'; } ?>>Yes</option>
                                    </select>
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">FB App ID</label>
                                    <input 	class="form-control regcom" type="text" name="fb_app_id" id="fb_app_id" value="<?php echo $result->fb_app_id; ?>" >
                                    </div> 

                                    <div class="form-group">
                                    <label  class="intrate">FB Secret Key</label>
                                    <input  class="form-control regcom" type="text" name="fb_sec_key" id="fb_sec_key" value="<?php echo $result->fb_sec_key; ?>" >
                                    </div>

                                    <?php

                                    $fb_url = str_replace('admin', 'home/facebook_login', base_url());
                                    $google_url = str_replace('admin', 'home/google_login', base_url());
                                    ?>

                                    <div class="form-group">
                                    <label  class="intrate">FB Redirect URL</label>
                                    <input  class="form-control regcom required" type="text" name="fb_redirect" id="fb_redirect" value="<?php echo $fb_url; ?>" readonly>
                                    </div>
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Sender Id</label>
                                    <input 	class="form-control regcom required" type="text" name="sender_id" data-parsley-trigger="keyup" required="" id="sender_id" value="<?php echo $result->sender_id; ?>" >
                                    </div>								
			
									<div class="form-group">
                                    <label  class="intrate">Sms username</label>
                                    <input 	class="form-control regcom required" type="text" name="sms_username" data-parsley-trigger="keyup" required="" id="sms_username" value="<?php echo $result->sms_username; ?>" >
                                    </div>
								   
								    <div class="form-group">
                                    <label  class="intrate">Sms Password</label>
                                    <input 	class="form-control regcom required" type="text" name="sms_password" data-parsley-trigger="keyup" required="" id="sms_password" value="<?php echo $result->sms_password; ?>" >
                                    </div> 
									
									
									  <div class="form-group">
                                    <label  class="intrate">Languages</label>
                                    <input 	class="form-control regcom required" type="text" name="languages" data-parsley-trigger="keyup" required="" id="languages" value="<?php echo $result->languages; ?>" >
                                    </div> 

								    <div class="form-group">
                                    <label  class="intrate">Sidebar</label>
                                    <input 	class="form-control regcom required" type="text" name="sidebar" data-parsley-trigger="keyup" required="" id="sidebar" value="<?php echo $result->sidebar; ?>" >
                                    </div> -->

									<div class="form-group">
                                    <label  class="intrate">Paypal</label>
                                    <input 	class="form-control regcom required" type="text" name="paypal" data-parsley-trigger="keyup" required="" id="paypal" value="<?php echo $result->paypal; ?>" >
                                    </div> 
									
									<div class="form-group">
                                    <label  class="intrate">Paypalid</label>
                                    <input 	class="form-control regcom required" type="text" name="paypalid" data-parsley-trigger="keyup" required="" id="paypalid" value="<?php echo $result->paypalid; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Serv_Secret_Key</label>
                                    <input 	class="form-control regcom required" type="text" name="serv_secret_key" data-parsley-trigger="keyup" required="" id="serv_secret_key" value="<?php echo $result->serv_secret_key; ?>" >
                                    </div>
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Analatic Code</label>
                                    <input 	class="form-control regcom required" type="text" name="analatic_code" data-parsley-trigger="keyup" required="" id="analatic_code" value="<?php echo $result->analatic_code; ?>" >
                                    </div> -->
									<div class="form-group">
									     <label  class="intrate">Select Delivery End Timing</label>
									 <div id="datetimepicker" class="input-append">
                                    <input data-format="hh:mm:ss" id="delivery_end_timing" name="delivery_end_timing" type="text"></input>
                                    <span class="add-on">
                                     <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
                                    </span>
                                     </div>
								   </div>
								   
                     <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Save" id="taxiadd">                      
                     </div>
                  </div>
				  
				        <div class="col-md-6">
						          
						            								          
								    
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Measurements</label>
                                    <input 	class="form-control regcom required" type="text" name="measurements" data-parsley-trigger="keyup" required="" id="measurements" value="<?php echo $result->measurements; ?>" >
                                    </div> -->
									
									<div class="form-group">
                                    <label  class="intrate">Currency</label>
                                    <input 	class="form-control regcom required" type="text" name="currency" data-parsley-trigger="keyup" required="" id="currency" value="<?php echo $result->currency; ?>" >
                                    </div>
									
									
									<div class="form-group">
                                    <label  class="intrate">Currency Symbol</label>
                                    <input 	class="form-control regcom required" type="text" name="currency_symbol" data-parsley-trigger="keyup" required="" id="currency_symbol" value="<?php echo $result->currency_symbol; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Payment Option</label><br/>
                                    <?php

                                    $payment = explode(',',$result->paypal_option);

                                    ?>
                                    <label><input type="checkbox" name="paypal_option[]" id="card" value="Credit_Card" <?php if(in_array('Credit_Card', $payment)){ echo 'checked'; } ?> /> Credit Card</label>
                                    <label><input type="checkbox" name="paypal_option[]" id="cash" value="Cash" <?php if(in_array('Cash', $payment)){ echo 'checked'; } ?> /> Cash</label>
                                    <label><input type="checkbox" name="paypal_option[]" id="paypal" value="PayPal" <?php if(in_array('PayPal', $payment)){ echo 'checked'; } ?> /> Paypal</label>
                                    <!-- <input 	class="form-control regcom required" type="text" name="paypal_option" data-parsley-trigger="keyup" required="" id="paypal_option" value="<?php echo $result->paypal_option; ?>" > -->
                                    </div>
									
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Card Option</label>
                                    <input 	class="form-control regcom required" type="text" name="card_option" data-parsley-trigger="keyup" required="" id="card_option" value="<?php echo $result->card_option; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Verification</label>
                                    <input 	class="form-control regcom required" type="text" name="verification" data-parsley-trigger="keyup" required="" id="verification" value="<?php echo $result->verification; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Mechanic Assigned</label>
                                    <input 	class="form-control regcom required" type="text" name="mechanic_assigned" data-parsley-trigger="keyup" required="" id="mechanic_assigned" value="<?php echo $result->mechanic_assigned; ?>" >
                                    </div> -->
									
									<div class="form-group">
                                    <label  class="intrate">Authorize Net Url</label>
                                    <input 	class="form-control regcom required" type="text" name="authorize_net_url" data-parsley-trigger="keyup" required="" id="authorize_net_url" value="<?php echo $result->authorize_net_url; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Authorize Key</label>
                                    <input 	class="form-control regcom required" type="text" name="authorize_key" data-parsley-trigger="keyup" required="" id="authorize_key" value="<?php echo $result->authorize_key; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Authorize ID</label>
                                    <input 	class="form-control regcom required" type="text" name="authorize_id" data-parsley-trigger="keyup" required="" id="authorize_id" value="<?php echo $result->authorize_id; ?>" >
                                    </div>

                                    <div class="form-group">
                                    <label  class="intrate">Payment Type</label>
                                    <select class="form-control" name="payment_type" id="payment_type">
                                        <option value="0" <?php if($result->payment_type=='0') echo 'selected="SELECTED"'; ?>>Sandbox</option>
                                        <option value="1" <?php if($result->payment_type=='1') echo 'selected="SELECTED"'; ?>>Live</option>
                                    </select>
                                    
                                    </div>


                                    
									
									<!-- <div class="form-group">
                                    <label  class="intrate">Braintree Merchant Id</label>
                                    <input 	class="form-control regcom required" type="text" name="braintree_merchant_id" data-parsley-trigger="keyup" required="" id="braintree_merchant_id" value="<?php echo $result->braintree_merchant_id; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Braintree Public Key</label>
                                    <input 	class="form-control regcom required" type="text" name="braintree_public_key" data-parsley-trigger="keyup" required="" id="braintree_public_key" value="<?php echo $result->braintree_public_key; ?>" >
                                    </div>
									
									<div class="form-group">
                                    <label  class="intrate">Braintree Private Key</label>
                                    <input 	class="form-control regcom required" type="text" name="braintree_private_key" data-parsley-trigger="keyup" required="" id="braintree_private_key" value="<?php echo $result->braintree_private_key; ?>" >
                                    </div> -->

                                    
                                    
                                    
                                    <div class="form-group">
                                    <label  class="intrate">Google App ID</label>
                                    <input  class="form-control regcom" type="text" name="google_app_id" id="google_app_id" value="<?php echo $result->google_app_id; ?>" >
                                    </div> 

                                    <div class="form-group">
                                    <label  class="intrate">Google Secret Key</label>
                                    <input  class="form-control regcom" type="text" name="google_sec_key" id="google_sec_key" value="<?php echo $result->google_sec_key; ?>" >
                                    </div>

                                    

                                    <div class="form-group">
                                    <label  class="intrate">Google Redirect URL</label>
                                    <input  class="form-control regcom required" type="text" name="fb_redirect" id="fb_redirect" value="<?php echo $google_url; ?>" readonly>
                                    </div>
								   
								   
								   	
						           <div class="form-group has-feedback">
								   <label for="exampleInputEmail1">Logo</label>
								   <input name="logo" class="" accept="image/*" type="file">
								   <img src="<?php echo $result->logo; ?>" width="100px" height="100px" alt="Picture Not Found"/>
								   </div>							   
								   
								   <div class="form-group has-feedback">
								   <label for="exampleInputEmail1">Favicon</label>
								   <input name="favicon"  type="file" class="">
								   <img src="<?php echo $result->favicon; ?>" width="25px" height="25px" alt="Picture Not Found"/>
								   </div>							 		 
		                </div>
		                
			<html>
  <head>
   
  </head>
  <body>
   
    <script type="text/javascript"
     src="<?php echo base_url();?>assets/js/bootstrap-datetimepicker.min.js">
    </script>
    <script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        pickDate: false
      });
    </script>
  </body>
<html>
             </div><!-- /.box-body -->
  
                </form>
              </div><!-- /.box -->
            </div>
            
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div>
