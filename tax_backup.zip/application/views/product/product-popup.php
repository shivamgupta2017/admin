<table class="table table-bordered" >
  <tbody> 
  <tr>
   <td style="width:50%">
      <h1><?php echo $data[0]->product_name;?><br></h1>
        <div style="width:100%;height:170px;margin:0 auto; background-size:contain; background-image:url(<?php echo base_url()."assets/uploads/product/".$data[0]->image;?>); background-position:center; background-repeat:no-repeat"></div><br>
        <?php echo $data[0]->details;?><br>
        <?php echo $data[0]->name;?><br>
        <?php echo $data[0]->rate;?>
        <?php if($data[0]->is_inclusive){echo "Exclusive";}else{echo "Inclusive";};?>
     
  </td>
  <td>
      <table class="table">
          <tr><td colspan="4">Unit Details</td></tr>
          <tr>
              <th>Weight</th><th>Selling Price</th><th>Cost Price</th><th>Max limit</th>
          </tr>
        <?php foreach($selected_unit as $temp){?>
          <tr>
              <td><?php echo $temp->weight.' '.$temp->unit;;?></td><td><?php echo $temp->price;?></td><td>NA</td><td><?php echo $temp->max_limit;?></td>
          </tr>
          <?php }?>
      </table>
  </td>
  </tr>
  <!--  <td colspan="5">-->
  <!--    <table class="table">-->
  <!--      <tbody>-->
  <!--      <tr>-->
  <!--        <th>#</th>-->
  <!--        <th>Product Name</th>-->
  <!--        <th>Details</th>-->
  <!--        <th>Qty</th>-->
  <!--         <th>Weight</th>-->
  <!--      </tr>-->
 <!--    -->
  <!--      if($data != NULL){-->
  <!--      foreach ($data as $rs) { ?>-->
  <!--      <tr>     -->
  <!--        <td><image style="width:100px;height:100px" src="<?php echo base_url()."assets/uploads/product/".$rs->image; ?>"></td>-->
  <!--        <td><?php echo $rs->product_name; ?></td>-->
  <!--        <td><?php echo $rs->details; ?></td>-->
  <!--        <td><?php echo $rs->tax_id;?></td>-->
  <!--         <td><?php echo $rs->is_inclusive;?></td>-->
  <!--      </tr>-->
  <!--     -->
        
  <!--      } }else{?><td>No Products In this Order</td> } ?>-->
  <!--        -->
  <!--          <tr style="background-color:#4a4f56">-->
  <!--          <td colspan="2" style="background-color:white"></td>-->
  <!--          <td><input type="text" value="<?php echo $temp->unit;?>"></td>-->
  <!--          <td><input type="text" value="<?php echo $temp->price;?>"></td>-->
  <!--          <td><input type="text" value="<?php echo $temp->basic_weight;?>"></td>-->
  <!--      </tr>-->
  <!--      -->
  <!--      }?>-->
  <!--      </tbody>-->
  <!--    </table>-->
  <!--  </td>-->
  <!--</tr>-->
  </tbody>
</table>