<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {


  function __construct(){
    parent::__construct();
    $this->load->model('basic');
    $this->load->database();
}

public function create_invoice(){
    $template['title'] = "Create Invoice";
    $template['users'] = $this->basic->get_data('users','','*');
    $template['product'] = $this->basic->get_data('products','','*');
    $template['page']  = "Invoice/invoice";
    $this->load->view('template',$template);
}
function get_address(){
    $id = $this->basic->get_post_data();
    $where['where'] = array('user_id'=>$id['id']);
    $result = $this->basic->get_data('addaddress',$where,'*');
    print_r(json_encode($result));
}

function generate_invoice(){
   $data = $this->basic->get_post_data();
   $user_details = explode('&',$data['user_name']);
   $join = array('addaddress'=>'users.user_id = addaddress.user_id,inner');
   $where['where']= array('users.user_id'=>$user_details[0]);
   $temp['user_details'] = $this->basic->get_data('users',$where,'addaddress.*,users.*',$join);
   for($i=1;$i<$data['option_counts'];++$i){
       $unit = explode(' ',$data['weight'.$i]);
       $where['where'] = array('product_id'=>$data['product_id'.$i]);
       $tax = $this->basic->get_data('tax_product_mapping',$where,'SUM(rate) as total_rate');
    $temp['products'][$i]['name'] = $data['product_name'.$i];
    $temp['products'][$i]['quantity'] = $data['quantity'.$i];
    $temp['products'][$i]['size'] = $unit[0];
    $temp['products'][$i]['product_unit'] = $unit[1];
    $temp['products'][$i]['price'] = $data['price'.$i];
    $temp['products'][$i]['rate'] = $tax[0]->total_rate;
   }
   $this->load->view('Pdf/pdf',$temp);
    $this->session->set_flashdata('message', array('message' => "Invoice Created Succeefully",'class' => 'success'));	
    redirect(base_url().'Invoice/create_invoice');
}
function get_weights(){
    $id = $this->basic->get_post_data();
    $where['where'] = array('unit_product_mapping.product_id'=>$id['product_id']);
    $join = array('unit_of_product'=>'unit_product_mapping.unit_id = unit_of_product.unit_product_id,inner');
    //$result =  $this->basic->get_data('unit_product_mapping',$where,'unit_product_mapping.*,unit_of_product.*',$join);
    print_r(json_encode($this->basic->get_data('unit_product_mapping',$where,'unit_product_mapping.*,unit_of_product.*',$join)));
}
}
?>