<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
include(APPPATH.'libraries/REST_Controller.php');
class Service extends REST_Controller{

function __construct()
    {
        // Construct our parent class
        parent::__construct();
       $this->load->model('basic');
       $this->load->database();
       $this->load->library('form_validation');
       date_default_timezone_set('Asia/Kolkata');
    
 }
 
function serviceResponse($data=array(),$response,$status=0)
     {
            $data = array('data'=>$data);
            $response = array('message'=>$response,'status'=>$status);
            $result = array();
            array_push($result,$data);
            array_push($result,array('response'=>$response));
            $this->response(json_decode(json_encode ($result), true), 200); 
     }  
     
function create_message($data){
    
    if(!empty($data)){
        $status = 1;
        $message = "Request Executed Successfully";
    }
    
    else{
        $status = 0;
        $message = "Unable to Executed Request";
    }
    
    $this->serviceResponse($data,$message,$status);
}

  public function get_products_post(){
     $where['where'] = array('products.is_deleted'=>'0');
     $result = $this->basic->get_data('products',$where,'*');
     $this->create_message($result);
  }
  
  public function get_product_details_post(){
     $data = $this->basic->get_file_content();
     $where['where'] = array('product_details.product_id' => $data['product_id'],'product_details.is_deleted'=>0);
     $join = array("unit_product_mapping" => "unit_of_product.unit_product_id = unit_product_mapping.unit_id,inner");
     $result['product_details'] = $this->basic->get_data('product_details',$where,'product_details.*');
     $where['where'] = array('unit_product_mapping.product_id'=>$data['product_id']);
     $result['unit_details'] = $this->basic->get_data('unit_of_product',$where,'unit_of_product.*,unit_product_mapping.*',$join);
     $this->create_message($result);
  }
  
  public function create_order_post(){
     $data = $this->basic->get_file_content();
     $temp['user_id'] = $data['user_id'];
     $temp['order_date'] = date('Y-m-d');
     $temp['order_status'] = "Pending";
     $temp['delivery_date'] = $data['delivery_date'];
     $temp['is_express'] = $data['is_express'];
     $data['order_id'] = $this->basic->insert_data_id('orders',$temp);
     if($data['is_express']){
         $this->load->helper('notification');
         web_push();
     }
     foreach($data['order_products'] as $temp3)
     {
     $where['where']=array('product_details.product_id'=>$temp3['product_id'],'unit_product_mapping.unit_product_mapping_id'=>$temp3['unit_mapping_id']);
    $join=array('unit_product_mapping'=>'product_details.product_id = unit_product_mapping.product_id,inner',
                    'unit_of_product'=>'unit_product_mapping.unit_id = unit_of_product.unit_product_id,inner');
      $select = 'product_details.*,unit_of_product.*,unit_product_mapping.price,unit_product_mapping.weight';
      $temp_data = $this->basic->get_data('product_details',$where,$select,$join);
      $temp3['name'] = $temp_data[0]->product_name;
      $temp3['order_id'] = $data['order_id'];
      $temp3['price'] = $temp_data[0]->price;
      $temp3['total_price'] = $temp_data[0]->price*$temp3['quantity'];
      $temp3['size'] = $temp_data[0]->weight;
      unset($data['user_id'],$data['delivery_date'],$temp3['unit_mapping_id']);
      $this->basic->insert_data('order_products',$temp3);
    }
    
     $this->create_message($data['order_id']);
  }
  
  public function login_post(){
     $data = $this->basic->get_file_content();
     $select = array('email','first_name','last_name','user_id', 'is_pass_changed');
     $where = array('email' => $data['email'],'password' => sha1($data['password']),'active'=>1);
     $result = $this->basic->is_unique_id('users',$where,'',$select);
     if($result){
     $where = array('user_id'=>$result->user_id);     
     $temp['player_id'] = $data['player_id'];
     $this->basic->update_data('users',$where,$temp);
     }
     
     $this->create_message($result);
  }
  
  public function get_orders_post(){
    $data = $this->basic->get_file_content();
    $where['where'] = array('user_id'=>$data['user_id']);
    $result = $this->basic->get_data('orders',$where,'*');
     $this->create_message($result);
  }
  
  public function get_order_details_post(){
    $data = $this->basic->get_file_content();
    $where['where'] = array('order_id'=>$data['order_id'],'is_verified !='=>1);
    $result = $this->basic->get_data('order_products',$where,'*');
    $this->create_message($result);
  }
  
  public function update_order_post(){
      $data = $this->basic->get_post_data();
      foreach($data['order_data'] as $temp){
            $temp['order_id'] = $data['order_id'];
            $result = $this->basic->insert_data('update_order',$temp);
      }
      $this->create_message($result);
  }
  
  public function store_concern_post()
  {
      $data = $this->basic->get_file_content();
      $temp['user_id'] = $data['user_id'];
      $temp['order_id'] = $data['selected_order_id'];
      $temp['message'] = $data['message'];
      /*$data['order_id'] = $this->basic->insert_data_id('orders',$temp);*/  
      $result = $this->db->get_where('customer_registration', array('id' => $temp['user_id']))->result_array(); 
      $temp['email'] = $result[0]['email'];  
      $temp['phone'] = $result[0]['phone'];
      //$temp['name'] = +$result[0]['last_name'];
      $temp['name'] = $result[0]['first_name'] . ' ' . $result[0]['last_name'];
      $sql = $this->db->set($temp)->get_compiled_insert('complaints');
      $this->db->query($sql);
      if($this->db->affected_rows())
      $this->create_message('success');
  }
  
  public function express_shipping_charges_post()
  {
    $data = $this->basic->get_file_content();
    $query = $this->db->select('city.express_shipping_charges')->from('city')
    ->join('users', 'users.zipcode = city.postal_code', 'inner')
    ->where('users.user_id', $data['user_id'])
    ->get()->row();
    $this->create_message($query);
  }
  public function change_user_password_post()
  {
      $data=$this->basic->get_file_content();
      $query = $this->db->set('password', sha1($data['pass2']))->set('is_pass_changed', '1')->where('user_id', $data['user_id'])->update('users');
      $this->create_message($query);
  }
  
  public function get_pass_changed_status_post()
  {
      $data=$this->basic->get_file_content();
      
      $query = $this->db->select('is_pass_changed')->from('users')->where('users.user_id', $data['user_id'])->get()->row();
      
     $this->create_message($query);
  }
  public function verify_order_post(){
      $data = $this->basic->get_file_content();
      $id = $data['order_id'];
      foreach(json_decode($data['order_details'],true) as $temp){
           $where = array('order_id'=>$data['order_id'],'product_id'=>$temp);
           $this->basic->update_data('order_products',$where,array('is_verified'=>1));
      }
      $where['where'] = array('order_id'=>$id);
      $temp3['order_id'] = $data['order_id'];
      $temp2 = $this->basic->get_data('payments',$where,'invoice_id,order_id','','','','payment_id desc');
      if(!empty($temp2[0]->order_id)){
        $temp3['invoice_id'] = $temp2[0]->invoice_id;
        $where = array('order_id'=>$temp2[0]->order_id); 
        $this->basic->delete_data('payments',$where);
      }else{
          $temp3['invoice_id'] = 1;
      }
      $where['where'] = array('is_verified'=>1,'order_id'=>$id);
      $temp2 = $this->basic->get_data('order_products',$where,'SUM(total_price) as amount');
      $temp3['amount'] = $temp2[0]->amount;
      $temp3['due_date'] = date('Y-m-d',strtotime('+1 month',strtotime(date('Y-m-d'))));
      $result = $this->basic->insert_data('payments',$temp3);
      $this->basic->generate_invoice($id);
       $join = array('orders'=>'orders.user_id = users.user_id,inner');
       $where['where'] = array('orders.id'=>$id);
       $data = array();
       $data = $this->basic->get_data('users',$where,'*',$join);
       $this->load->helper('notification');
       $link = base_url().'assets/pdfs/invoice/INV000'.$id.".pdf";
            $data['message'] = "Your Invoice is Generated Check it Here.";
             $data['first_name'] = $data[0]->first_name;
              $data['last_name'] = $data[0]->last_name;
               $data['device_id'] = $data[0]->player_id;
                $data['link'] = $link;
                 create_notification($data);
                  $this->create_message($result);
  }
 
 }
?>