<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment_ctrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set("Asia/Kolkata");
		$this->load->model('basic');
			if(!$this->session->userdata('logged_in_adminw1')) { 
			redirect(base_url());
		}
	}
	
	public function index(){
		 $template['page'] = 'Payment/payments';
		  $template['title'] = 'View Payments';
		    $join = array(
		                'orders'=>'payments.order_id = orders.id,inner',
		                'users'=>'orders.user_id = users.user_id,inner',
		                );
		   $template['data'] = $this->basic->get_data('payments','','payments.*,users.*',$join);
		    $this->load->view('template',$template);
	}
	
  public function edit_payment($id){
     $template['page'] = 'Payment/edit_payment';
      $template['title'] = 'Edit Products';
       if($_POST){
           $where = array('payment_id'=>$id);
           $data = $this->basic->get_post_data();
           if($data['action'] == 'cash'){
              unset($data['action']);
              $data['payment_status'] = 2;
              $data['paid_date'] = date('Y-m-d');
              $result = $this->basic->update_data('payments',$where,$data);
              $this->session->set_flashdata('message',array('message'=>'Updated Successfully','class'=>"success"));
              redirect('Payment_ctrl/edit_payment/'.$id,'refresh');
           }
           elseif($data['action'] == 'cheque'){
              unset($data['action']);
              $data['payment_status'] = 1;
              $data['paid_date'] = date('Y-m-d');
              $result = $this->basic->update_data('payments',$where,$data);
              $this->session->set_flashdata('message',array('message'=>'Updated Successfully','class'=>"success"));
              redirect('Payment_ctrl/edit_payment/'.$id,'refresh');
           }
           elseif($data['action'] == 'online'){
              unset($data['action']);
              $data['payment_status'] = 1;
              $data['paid_date'] = date('Y-m-d');
              $result = $this->basic->update_data('payments',$where,$data);
              $this->session->set_flashdata('message',array('message'=>'Updated Successfully','class'=>"success"));
              redirect('Payment_ctrl/edit_payment/'.$id,'refresh');
           }
           elseif($data['action'] == 'swipe'){
              unset($data['action']);
              $data['payment_status'] = 2;
              $data['paid_date'] = date('Y-m-d');
              $result = $this->basic->update_data('payments',$where,$data);
              $this->session->set_flashdata('message',array('message'=>'Updated Successfully','class'=>"success"));
              redirect('Payment_ctrl/edit_payment/'.$id,'refresh');
           }else{
                $this->session->set_flashdata('message',array('message'=>'Unable to update','class'=>"danger"));
              redirect('Payment_ctrl/edit_payment/'.$id,'refresh');
           }
       }
       $this->load->view('template',$template);
  }
}
?>