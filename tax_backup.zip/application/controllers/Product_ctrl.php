<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_ctrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		date_default_timezone_set("Asia/Kolkata");
			 $this->load->model('basic');
		   	 $this->load->database();
			if(!$this->session->userdata('logged_in_adminw1')) { 
			redirect(base_url());
		}
	}

function add_products()
 {
 				if($_POST){
 					$data = $this->basic->get_post_data();
 					 $data1= array_slice($data,4);
					  $data= array_slice($data,0,3);
					  	$config = set_upload_options_product('assets/uploads/product');
				      //$this->load->library('upload');
				
				      $new_name = time()."_".$_FILES["image"]['name'];
				      $config['file_name'] = $new_name;
				      $data['image'] = $new_name;
					  	$this->upload->initialize($config);
							if ( ! $this->upload->do_upload('image')) 
							  {
								
								$this->session->set_flashdata('message', array('message' => "Display Picture : ".$this->upload->display_errors(), 'title' => 'Error !', 'class' => 'danger'));
								
							  }
					else{
							 $temp['product_name'] = $data['product_name'];
					  		$this->basic->insert_data('products',$temp);
					  		$data['product_id'] = $this->db->insert_id();
					  		$this->basic->insert_data('product_details',$data);
					  		 for ($i = 1; $i < $data1['option_count1']; $i++) {
 					            $data2['tax_id']      = $data1['tax_id' . $i];
					            $data2['rate']          = $data1['rate' . $i];
					            $this->db->where(array('product_id'=>$data['product_id'],'tax_id'=>$data2['tax_id']));
					            $temp = $this->db->delete('tax_product_mapping');
					            $data2['product_id'] = $data['product_id'];
					            $result = $this->db->insert('tax_product_mapping',$data2);
					            unset($data1['tax_id' . $i],$data1['rate' . $i]);
				            }
				            unset($data1['option_count1'],$data1['option_counts1']);
				              $data2 = array();
 						for($i=1;$i <  $data1['option_counts'];++$i){
 							
					                $data2['product_id'] = $data['product_id']; 
 				            	    $data2['unit_id']      = $data1['option_id' . $i];
					                $data2['price']          = $data1['price' . $i];
					                $data2['weight']          = $data1['weight' . $i];
					                $data2['max_limit']          = $data1['max_quantity' . $i];
					                $result = $this->db->insert('unit_product_mapping',$data2);
				          
 						}
 						if($result)
									 {
										  $this->session->set_flashdata('message',array('message' => 'Add Products Details successfully','class' => 'success'));
									 }
									 else
									 {
										 $this->session->set_flashdata('message', array('message' => 'Error','class' => 'error'));
									 }	
 					}
			}
 				   $template['unit'] = $this->basic->get_data('unit_of_product','','*');
 					$template['tax'] = $this->basic->get_data('tax','','*');
	 				 $template['page'] = 'product/clickkart_product';
			          $template['page_title'] = 'category';
                       $userdetails=$this->session->userdata('logged_in_adminw'); 
				        $this->load->view('template',$template);
 }
 	public function view_product(){
 					$template['data'] = $this->basic->get_data('product_details','','*');
	 				 $template['page'] = 'product/view_product';
			          $template['page_title'] = 'category';
				        $this->load->view('template',$template);
 	}
 	public function view_product_popup(){
 				  $data = $this->basic->get_post_data();
 				   $where['where'] = array('product_id'=>$data['prodetails']);
 				    $join = array('unit_of_product'=>'unit_product_mapping.unit_id = unit_of_product.unit_product_id,inner');
                     $template['selected_unit'] = $this->basic->get_data('unit_product_mapping',array('where'=>array('product_id'=>$data['prodetails'])),'*',$join);
                     $join = array('tax'=>'product_details.tax_id = tax.tax_id,inner');
 					  $template['data'] = $this->basic->get_data('product_details',$where,'product_details.*,tax.*',$join);
	 				   $template['page'] = 'product/view_product';
			            $template['page_title'] = 'category';
				         $this->load->view('product/product-popup',$template);
 	}
 	function delete_pro()
    {
				  $data1 = array(
						  "is_deleted" => '1'
									 );
				  $id = $this->uri->segment(3);
				  $this->basic->set_deleted('product_details',array('product_id'=>$id));
				  $result = $this->basic->set_deleted('products',array('product_id'=>$id));
				  $this->session->set_flashdata('message', array('message' => 'Deleted Successfully','class' => 'success'));
				  redirect(base_url().'Product_ctrl/view_product');
   }
// edit product

 function edit_pro()
  {
				  $template['page'] = 'product/editpro_view';
				  $template['title'] = 'Edit products';  
			      $id = $this->uri->segment(3);
			      $template['unit'] = $this->basic->get_data('unit_of_product','','*');
			      $template['data'] = $this->basic->get_data('product_details',array('where'=>array('product_id'=>$id)),'*');
	              $template['tax'] = $this->basic->get_data('tax','','*');
	              $where['where'] = array('product_id'=>$id);
	              $template['selected_tax'] = $this->basic->get_data('product_details',$where,'tax_id');
	              // $template['unit'] = $this->basic->get_data('unit_of_product',,'*');
	              // $template['selected_unit'] = $this->basic->get_data('unit_mapping_products',array('product_id'=>$id),'*');
		   	      if(!empty($template['data'])){
         
					if($_POST){
 					$data = $this->basic->get_post_data();
 					 $data1= array_slice($data,5);
					  $data= array_slice($data,0,3);
					  	$config = set_upload_options_product('assets/uploads/product');
				      //$this->load->library('upload');
					 if(! empty($_FILES["image"]['name'])){
				      		$new_name = time()."_".$_FILES["image"]['name'];
				      		 $config['file_name'] = $new_name;
				      		  $data['image'] = $new_name;
					  		   $this->upload->initialize($config);
							    $this->upload->do_upload('image');
					}
							 $temp['product_name'] = $data['product_name'];
							 $where = array('product_id'=>$id);
					  		 $this->basic->update_data('products',$where,$temp);
					  		 $data['product_id'] = $id;
					  		 $where = array('product_id'=>$id);
					  		$this->basic->update_data('product_details',$where,$data);
					  		$result = $this->basic->delete_data('unit_product_mapping',$where);
					  		 $data2 = array();
				                 for ($i = 1; $i < $data1['option_count1']; $i++) {
 					$data2['tax_id']      = $data1['tax_id' . $i];
					$data2['rate']          = $data1['rate' . $i];
					$this->db->where(array('product_id'=>$id,'tax_id'=>$data2['tax_id']));
					$temp = $this->db->delete('tax_product_mapping');
					$data2['product_id'] = $id;
					$result = $this->db->insert('tax_product_mapping',$data2);
					unset($data1['tax_id' . $i],$data1['rate' . $i]);
				}unset($data1['option_count1'],$data1['option_counts1']);
			                         $data2 = array();
 						for($i=1;$i <  $data1['option_counts'];++$i){
 							
					                $data2['product_id'] = $data['product_id']; 
 				            	    $data2['unit_id']      = $data1['option_id' . $i];
					                $data2['price']          = $data1['price' . $i];
					                $data2['weight']          = $data1['weight' . $i];
					                $data2['max_limit']          = $data1['max_quantity' . $i];
					                $result = $this->db->insert('unit_product_mapping',$data2);
				          
 						}
 						if($result)
									 {
										  $this->session->set_flashdata('message',array('message' => 'Add Products Details successfully','class' => 'success'));
									 }
									 else
									 {
										 $this->session->set_flashdata('message', array('message' => 'Error','class' => 'error'));
									 }	
 					
			}
				  }
				  else
				  {
					   $this->session->set_flashdata('message', array('message' => "You don't have permission to access.",'class' => 'danger'));	
			           redirect(base_url().'Home_ctrl/edit_pro/'.$id);
				  }
			
			
			$this->load->view('template',$template);		   		   	  
	  
  }
  public function selected_unit(){
      $param = $this->basic->get_post_data();
      $join = array('unit_of_product'=>'unit_product_mapping.unit_id = unit_of_product.unit_product_id,inner');
      $data = $this->basic->get_data('unit_product_mapping',array('where'=>array('product_id'=>$param['id'])),'*',$join);
      print_r(json_encode($data));
  }
 } 
 
 ?>