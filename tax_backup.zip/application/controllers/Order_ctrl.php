<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_ctrl extends CI_Controller{

 public function __construct(){
 	parent::__construct();
 	$this->load->model('basic');
 	$this->load->database();
 }
 
 public function index(){
 	$select = 'orders.*,users.zipcode,users.address,users.username';
 	$join = array('users' => 'orders.user_id = users.user_id,inner');
 	$template['data'] = $this->basic->get_data('orders','',$select,$join,'','','orders.id desc');
 	$template['page'] = "Order/view_order";
 	$template['page_title'] = 'View Order';
 	$this->load->view('template',$template);
 }
 
 public function view_order(){
 	$data = $this->basic->get_post_data();
 	$where['where'] = array('order_id'=>$data['orderdetails']);
    $join = array(
      'product_details'=>'order_products.product_id = product_details.product_id,inner');
    $result['data'] = $this->basic->get_data('order_products',$where,'*',$join);
    $this->load->view('Order/view-order-popup',$result);
 }
 
 public function generate_challan($id){
     $select = array('order_products.*','orders.id as order_id','orders.*','product_details.*','tax.name as tax_name','tax.rate');
     $where['where'] = array('order_products.order_id'=>$id);
     $join = array(
            'orders'=>'order_products.order_id = orders.id,inner',
            'product_details'=>'product_details.product_id = order_products.product_id,inner',
            'tax'=>'product_details.tax_id = tax.tax_id,inner');
     $data['products'] = $this->basic->get_data('order_products',$where,$select,$join);
     $where['where'] = array('user_id'=>$data['products'][0]->user_id);
     $data['user_details'] = $this->basic->get_data('users',$where,'*');
     $this->load->view('Pdf/challan',$data);
 }
 public function update_order($id='',$action=''){
 	if($action == 0){
 		$this->basic->update_data('orders',array('id'=>$id),array('status'=>1,'order_status'=>'Out for Delivery'));
 		$this->session->set_flashdata('message',array('message'=>"Updated Successfully",'class'=>'success'));
 		 redirect(base_url().'Order_ctrl');
 	}
//  	else if($action == 1){
// 		$this->basic->update_data('orders',array('id'=>$id),array('status'=>2,'order_status'=>'Delivered'));
// 		$this->session->set_flashdata('message',array('message'=>"Updated Successfully",'class'=>'success'));
// 		 redirect(base_url().'Order_ctrl');
//  	}
//  		else if($action > 1){
// 		$this->session->set_flashdata('message',array('message'=>"Order Already Delivered",'class'=>'danger'));
// 		 redirect(base_url().'Order_ctrl');
//  	}
 }
}
?>
<script>
   

</script>