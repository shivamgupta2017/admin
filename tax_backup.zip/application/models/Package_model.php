<?php 

class Package_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
 	}
 	public function get_package($id=''){
		 if($id==''){
		$this->db->select('*');
		$this->db->from('package');
		$query = $this->db->get();
		$result = $query->result(); 
				 return $result;
		 }
		 else{
		 	$this->db->select('*');
		$this->db->from('package');
		$this->db->where('id',$id);
		$query = $this->db->get();
		$result = $query->row(); 
				 return $result;
		 }
		 
	 }
	 public function get_products($id){
	 	$this->db->select('package_products.*,package_products.is_deleted as deleted,package_products.product_status as status,products.*');
	 	$this->db->from('package_products');
	 	$this->db->where('package_id',$id);
	 	$this->db->join('products','package_products.item_id = products.id');
	 	$query = $this->db->get();
	 	$result = $query->result();
	 	return $result;

	 }
	 public function active_deactive($id) 
	 {          
	           $this->db->select('product_status');
	           $this->db->from('products');
	           $query = $this->db->where('id',$id);
	           $status = $query->get()->row();
	          if($status->product_status=='1'){$data['product_status']='0';$result = 'deactived';}else{$data['product_status']='1';$result = 'actived';}
		        $this->db->where('id',$id);
			    $this->db->update('products',$data);
			    return $result; 				
	 }
	 public function check_duplicate($package_id,$product_id){
	 	$this->db->select('*');
	 	$this->db->from('package_products');
	 	$array = array('package_id'=>$package_id,'item_id'=>$product_id);
	 	$this->db->where($array);
	 	$query = $this->db->get()->result();
	 	if($query){
	 		return 0;
	 	}else{
	 		return 1;
	 	}
	 }
	 public function get_sizes($id='',$size_id=''){
	 	if($id=='' && $size_id==''){
	 	$this->db->select('*');
	 	$this->db->from('package_size');
	 	$result = $this->db->get()->result();
	 	return $result;
	}
		else if($size_id==''){
		$this->db->select('size_id,package_size.size_name');
	 	$this->db->from('package_and_sizes');
	 	$this->db->join('package_size','package_and_sizes.size_id = package_size.id');
	 	$this->db->where('package_and_sizes.package_id',$id);
	 	$result = $this->db->get()->result();
	 	return $result;

		}
		else if($id!='' && $size_id!=''){
			$this->db->select('product_id');
	 		$this->db->from('next_day_selection');
	 		$array = array('package_id'=>$id,'size_id'=>$size_id);
	 		$this->db->where($array);
	 		$result = $this->db->get()->result();
	 		return $result;

		}
	 }
	 public function get_daily_needs($action=''){
	     if($action == "package"){
	         $result = $this->db->select('DISTINCT(next_day_needs.product_id),next_day_needs.quantity,products.product_name,products.image,customer_registration.first_name,customer_registration.last_name,unit_of_product.*')->from('next_day_needs')->join('products','next_day_needs.product_id = products.id')->join('unit_of_product','next_day_needs.unit_id = unit_of_product.tbl_id')->join('customer_registration','next_day_needs.cust_id = customer_registration.id')->get()->result();
	         foreach($result as $index => $data){
	        $result[$index]->total_weight= $this->db->select('SUM(total_weight) as total_weight')->from('next_day_needs')->where('product_id',$data->product_id)->get()->row();
	        }
	 	    return $result;
	     }
	    else if($action == 'subscription'){
	        $next_date = date('Y-m-d',strtotime('+1 day',strtotime(date('Y-m-d'))));
	         $result = $this->db->select('DISTINCT(subs_used_data.product_id),products.product_name,products.image,cust_subscription.unit_mapping_id')->from('subs_used_data')->join('cust_subscription','subs_used_data.subscription_id = cust_subscription.id')->join('customer_registration','subs_used_data.cust_id = customer_registration.id')->join('products','subs_used_data.product_id = products.id')->where('subs_used_data.date',$next_date)->get()->result();
	    	 foreach($result as $index => $data ){
	    	     $result[$index]->total_quantity = $this->db->select('SUM(qty)as qty,subs_used_data.price,SUM(extra_qty) as extra_qty')->from('subs_used_data')->where(array('date'=>$next_date,'product_id'=>$data->product_id))->get()->row();
	    	     $result[$index]->basic_weight = $this->db->select('unit_of_product.basic_weight,unit_product_mapping.weight')->from('unit_of_product')->join('unit_product_mapping','unit_of_product.tbl_id = unit_product_mapping.unit_id')->where('unit_product_mapping.tbl_id',$data->unit_mapping_id)->get()->row();
	    	 }
	    	return $result;
	     }
	    else if($action == 'orders'){
	          $next_date = date('Y-m-d',strtotime('+1 day',strtotime(date('Y-m-d'))));
	         $result = $this->db->select('DISTINCT(order_products.product_id),order_products.unit,products.product_name,products.image')->from('order_products')->join('products','order_products.product_id = products.id')->where('order_products.delivery_date',$next_date)->get()->result();
	        	foreach($result as $index => $temp){
	        	    $result[$index]->total_weight = $this->db->select('(SUM(order_products.weight)*order_products.basic_weight) as total_weight')->from('order_products')->where(array('product_id'=>$temp->product_id,'delivery_date'=>$next_date))->get()->row();
	        	}
	    	return $result;
	    }
	     
	 }
	 public function selected_tax($id){
	     return $this->db->select('tax_id')->from('package')->where('id',$id)->get()->row();
	 }
	}
	 ?>