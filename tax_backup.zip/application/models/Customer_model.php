<?php 

class Customer_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
 	}
// view customer details	
	 public function get_customer_details(){
		 $query = $this->db->select('customer_registration.*')->join('addaddress','customer_registration.id = addaddress.user_id')->where('customer_status','1')->get('customer_registration');
		 $result = $query->result();
		 return $result;

	 }	 
	 	
//delete customer	 
	 public function delete_customer($id,$data1){
		  $this->db->where('id',$id);
				 $result = $this->db->update('customer_registration',$data1);
				 return $result;
		 
		 
	 }
//popup customer details	 
	 public function view_popup_customerdetails($id){
		  
		 $this->db->where('id', $id);
		 $query = $this->db->get('customer_registration');
		 $result = $query->row();
		 return $result;

	 }

// view order details	
	 public function get_order_details(){
		 $result = $this->db->select('orders.*,addaddress.address,addaddress.zip,addaddress.mobno')->from('orders')->join('addaddress','orders.delivery_add_id = addaddress.id')->order_by('orders.id','DESC')->get()->result();
		 return $result;

	 }	 
	 	
//delete order	 
	 public function delete_order($id,$data1){
		  $this->db->where('id',$id);
				 $result = $this->db->update('order',$data1);
				 return $result;
		 
		 
	 }
//popup order details	 
	 public function view_popup_orderdetails($id){
		  
		 $this->db->where('id', $id);
		 $query = $this->db->get('order');
		 $result = $query->row();
		 return $result;

	 }	

    function invoice($id){
        $result['order'] = $this->db->select('orders.*,addaddress.address,customer_registration.email')->from('orders')->join('customer_registration','orders.cust_id = customer_registration.id')->join('addaddress','orders.delivery_add_id = addaddress.id')->where(array('orders.id'=>$id))->get()->result();
		  $result['order_products'] = $this->db->select('order_products.*,products.product_name,products.image,tax.rate')->from('order_products')->join('products','order_products.product_id = products.id')->join('tax','products.tax_id = tax.tax_id')->where(array('order_products.order_id'=>$id))->get()->result();
		   return $result;
    }
    function bill_invoice($id){
        $action = $this->db->join('billing','cust_subscription.id = billing.subscription_id')->where('billing.billing_id',$id)->get('cust_subscription')->row();
        if($action->product_id){
        $result['bill'] = $this->db->select('billing.*,cust_subscription.unit_mapping_id,cust_subscription.product_id,addaddress.apartment,addaddress.address,addaddress.zip,customer_registration.due_amount,customer_registration.email,customer_registration.first_name,customer_registration.due_amount,customer_registration.last_name,customer_registration.phone,products.product_name,tax.rate as tax_rate,products.is_inclusive,tax.name as tax_name')->from('billing')->join('customer_registration','billing.cust_id = customer_registration.id')->join('cust_subscription','billing.subscription_id = cust_subscription.id')->join('addaddress','cust_subscription.delivery_add_id = addaddress.id')->join('products','cust_subscription.product_id = products.id')->join('tax','products.tax_id = tax.tax_id')->where(array('billing.billing_id'=>$id))->get()->row();
		      
		      $result['is_package'] = 0;
		      $start_date = date('Y-m-01',strtotime($result['bill']->month_bill));
		      $end_date = date('Y-m-t',strtotime($start_date));
		        $result['unit'] = $this->db->select('unit_of_product.unit')->from('unit_product_mapping')->join('unit_of_product','unit_product_mapping.unit_id = unit_of_product.tbl_id')->where('unit_product_mapping.tbl_id',$result['bill']->unit_mapping_id)->get()->row();
		        $result['billing_details'] = $this->db->select('subs_used_data.*')->from('subs_used_data')->where(array('subs_used_data.subscription_id'=>$result['bill']->subscription_id,'status'=>1,'subs_used_data.date >'=>$start_date,'subs_used_data.date <='=>$end_date))->get()->result();
		   }
		   else{
		        $result['bill'] = $this->db->select('billing.*,cust_subscription.unit_mapping_id,package.package_name as product_name,addaddress.apartment,addaddress.address,addaddress.zip,customer_registration.due_amount,customer_registration.email,customer_registration.first_name,customer_registration.last_name,customer_registration.phone,tax.rate as tax_rate,tax.name as tax_name,package.tax_id,package.is_inclusive,package_size.size_name')->from('billing')->join('customer_registration','billing.cust_id = customer_registration.id')->join('cust_subscription','billing.subscription_id = cust_subscription.id')->join('package_size','cust_subscription.package_size_id = package_size.id')->join('package','cust_subscription.package_id = package.id')->join('addaddress','cust_subscription.delivery_add_id = addaddress.id')->join('tax','package.tax_id = tax.tax_id')->where(array('billing.billing_id'=>$id))->get()->row();
		        $result['is_package'] = 1;
		        $start_date = date('Y-m-01',strtotime($result['bill']->month_bill));
		        $end_date = date('Y-m-t',strtotime($start_date));
		        $result['billing_details'] = $this->db->select('package_used_data.*,package_used_data.weight as qty')->from('package_used_data')->join('package','package_used_data.package_id = package.id')->where(array('package_used_data.subscription_id'=>$result['bill']->subscription_id,'package_used_data.status'=>1,'package_used_data.date >'=>$start_date,'package_used_data.date <='=>$end_date))->get()->result();
		        $result['unit'] = (object)array();
		        $result['unit']->unit = "g";
		  foreach($result['billing_details'] as $index=>$temp){
		      $result['billing_details'][$index]->extra_qty = 0;
		  }
		 
		   }
		   return $result;
		  
    }
	function view_booking_info($id){
    return $this->db->query("SELECT products.image,products.product_name,order_products.price,order_products.quantity,order_products.weight,order_products.unit FROM `order_products` INNER JOIN products ON order_products.product_id = products.id WHERE order_products.order_id =".$id)->result();
  }

  function view_book_data($id){
    return $this->db->where('id',$id)->get('bookingdetails')->row();
  } 

}
?>
	