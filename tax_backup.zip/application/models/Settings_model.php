<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
   }
   

	  
	 function settings_viewings(){
		 
		  $query = $this->db->query(" SELECT * FROM `settings` order by id DESC ")->row();
		  return $query ;
	 }
	 
	/* public function get_single_settings($id){
		
		  
		       $query = $this->db->where('id',$id);
			   $query = $this->db->get('settings');
			   $result = $query->row();
			   return $result;  
	 }	
	 */
	 public function update_settings($data){
	 	unset($data['fb_redirect']);
	 	unset($data['google_redirect']);


	 	$path = str_replace('\admin','',APPPATH);
		$path = $path.'config\facebook.php';
		$txt = '<?php ';
		$txt .='$config["appId"] = "'.$data['fb_app_id'].'";'."\r\n";
		$txt .='$config["secret"] = "'.$data['fb_sec_key'].'";'."\r\n";
		$txt .=' ?>';
		$myfile = fopen($path, "w") or die("Unable to open file!");
		echo fgets($myfile);
		fwrite($myfile, $txt);		
		fclose($myfile);


	 	$data['paypal_option'] = implode(',', $data['paypal_option']);
		 
		           //$this->db->where('id', $id);
				   $result = $this->db->update('settings', $data); 
			
				   return $result;
	 }
	 
  
   }
  ?>