<?php $config["appId"] = "337897363291861";
$config["secret"] = "c92f462feddbe90abcc20329a24b59b6";
 ?>