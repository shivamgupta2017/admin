<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
include(APPPATH.'libraries/REST_Controller.php');
class Service extends REST_Controller{

function __construct()
    {
        parent::__construct();
       $this->load->model('basic');
       $this->load->database();
       $this->load->library('form_validation');
       $this->load->helper('notification');
       $this->load->helper('email');
       date_default_timezone_set('Asia/Kolkata');
 }
 
function serviceResponse($data=array(),$response,$status=0)
     {
            $data = array('data'=>$data);
            $response = array('message'=>$response,'status'=>$status);
            $result = array();
            array_push($result,$data);
            array_push($result,array('response'=>$response));
            $this->response(json_decode(json_encode ($result), true), 200); 
     }  
     
function create_message($data){
    if(!empty($data)){
        $status = 1;
        $message = "Request Executed Successfully";
    }
    else{
        $status = 0;
        $message = "Unable to Executed Request";
    }
    $this->serviceResponse($data,$message,$status);
}

  public function get_products_post(){
     $where['where'] = array('{PRE}products.is_deleted'=>'0');
     $result = $this->basic->get_data('{PRE}products',$where,'*');
     $this->create_message($result);
  }
  
  public function get_product_details_post(){
     $data = $this->basic->get_file_content();
     $where['where'] = array('{PRE}product_details.product_id' => $data['product_id'],'{PRE}product_details.is_deleted'=>0);
     $join = array("unit_product_mapping" => "{PRE}unit_of_product.unit_product_id = {PRE}unit_product_mapping.unit_id,inner");
     $result['product_details'] = $this->basic->get_data('{PRE}product_details',$where,'{PRE}product_details.*');
     $where['where'] = array('{PRE}unit_product_mapping.product_id'=>$data['product_id']);
     $result['unit_details'] = $this->basic->get_data('{PRE}unit_of_product',$where,'{PRE}unit_of_product.*,{PRE}unit_product_mapping.*',$join);
     $this->create_message($result);
  }
  
  public function create_order_post(){
     $data = $this->basic->get_file_content();
     $user_id = $data['user_id'];
     $temp['user_id'] = $data['user_id'];
     $temp['order_date'] = date('Y-m-d');
     $temp['order_status'] = "Pending";
     $temp['delivery_date'] = $data['delivery_date'];
     $temp['is_express'] = $data['is_express'];
     $temp['selected_address_id'] = $data['selected_address_id'];
     $data['order_id'] = $this->basic->insert_data_id('{PRE}orders',$temp);
     if($data['is_express']){
         $this->load->helper('notification');
         web_push();
     }
     foreach($data['order_products'] as $index=>$temp3)
     {
     $where['where']=array('{PRE}product_details.product_id'=>$temp3['product_id'],'{PRE}unit_product_mapping.unit_product_mapping_id'=>$temp3['unit_mapping_id']);
    $join=array('{PRE}unit_product_mapping'=>'{PRE}product_details.product_id = {PRE}unit_product_mapping.product_id,inner',
                    '{PRE}unit_of_product'=>'{PRE}unit_product_mapping.unit_id = {PRE}unit_of_product.unit_product_id,inner');
      $select = '{PRE}product_details.*,{PRE}unit_of_product.*,{PRE}unit_product_mapping.price,{PRE}unit_product_mapping.weight';
      $temp_data = $this->basic->get_data('{PRE}product_details',$where,$select,$join);
      $temp3['name'] = $temp_data[0]->product_name;
      $temp3['order_id'] = $data['order_id'];
      $temp3['price'] = $temp_data[0]->price;
      $temp3['total_price'] = $temp_data[0]->price*$temp3['quantity'];
      $temp3['size'] = $temp_data[0]->weight;
      unset($data['user_id'],$data['delivery_date'],$temp3['unit_mapping_id']);
      $temp4[$index] = $temp3;
      $this->basic->insert_data('{PRE}order_products',$temp3);
    }
    if($data['order_id']){
                  web_push();
                  $temp4['data'] = $temp4;
                   $message = $this->load->view('Templates/email',$temp4,true);
                    $mail_data = array('first_name'=>'Minbazaar','email'=>$temp_data[0]->email,'message'=>$message,'subject'=>'Order Conformation');
                     send_mail($mail_data);
     }
     $this->create_message($data['order_id']);
  }
  
  public function login_post(){
     $data = $this->basic->get_file_content();
     $select = array('email','first_name','last_name','user_id', 'is_pass_changed');
     $where = array('email' => $data['email'],'password' => sha1($data['password']),'active'=>1);
     $result = $this->basic->is_unique_id('{PRE}users',$where,'',$select);
     if($result){
     $where = array('user_id'=>$result->user_id);     
     $temp['player_id'] = $data['player_id'];
     $this->basic->update_data('{PRE}users',$where,$temp);
     }
     
     $this->create_message($result);
  }
  
  public function get_orders_post(){
    $data = $this->basic->get_file_content();
    $where['where'] = array('user_id'=>$data['user_id']);
    $result = $this->basic->get_data('{PRE}orders',$where,'*','','','','id desc');
    $join = array('orders'=>'update_order_history.order_id = orders.id,inner');
    $check = $this->basic->get_data('{PRE}update_order_history',array('orders.user_id'=>$data['user_id']),'*',$join);
    if(!empty($check)){$result[0]->is_updated = 1;}
     $this->create_message($result);
  }
  

  public function get_order_details_post(){
    $data = $this->basic->get_file_content();
    $where['where'] = array('order_id'=>$data['order_id'],'is_verified !='=>1);
    $result = $this->basic->get_data('{PRE}order_products',$where,'*');
    $this->create_message($result);
  }
  
  public function update_order_post()
  {
      $data = $this->basic->get_file_content();
      foreach($data['product_details'] as $temp)
      {
            $temp['order_id'] = $data['order_id'];
            $result = $this->basic->insert_data('{PRE}update_order',$temp);
      }
      $this->create_message($result);
  }
  
  public function store_concern_post()
  {
        if(!empty($_FILES)){$data = $this->basic->get_post_data();$data['image_link'] = base_url()."uploads/".$_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'],$_SERVER['DOCUMENT_ROOT']."/admin/uploads/".$_FILES['file']['name']);
       }
       else{
        $data = $this->basic->get_file_content();
      }
        $temp = $this->basic->get_data('{PRE}users',array('where'=>array('user_id'=>$data['user_id'])),'*');
        $data['phone'] = $temp[0]->phone;
        $data['email'] = $temp[0]->email;
        $data['name']  = $temp[0]->first_name.' '.$temp[0]->last_name;
        $data['order_id'] = $data['selected_order_id'];
        unset($data['selected_order_id']);
        $result = $this->basic->insert_data('{PRE}complaints',$data);
        $this->create_message($result);
  }
  
  public function express_shipping_charges_post()
  {
    $data = $this->basic->get_file_content();
    $query = $this->db->select('{PRE}city.express_shipping_charges')->from('{PRE}city')
    ->join('{PRE}users', '{PRE}users.zipcode = {PRE}city.postal_code', 'inner')
    ->where('{PRE}users.user_id', $data['user_id'])
    ->get()->row();
    $this->create_message($query);
  }
  public function change_user_password_post()
  {
      $data = $this->basic->get_file_content();
      $where = array('password'=>sha1($data['current']));
      $check = $this->basic->is_exist('users',$where,'*');
      if(!empty($check)){
        $query = $this->db->set('password', sha1($data['current']))->set('is_pass_changed','1')->where('user_id',$data['user_id'])->update('{PRE}users');
      }else{
          $query = 0;
      }
      $this->create_message($query);
  }
  
  public function get_pass_changed_status_post()
  {
      $data=$this->basic->get_file_content();
      $query = $this->db->select('is_pass_changed')->from('{PRE}users')->where('{PRE}users.user_id', $data['user_id'])->get()->row();
     $this->create_message($query);
  }
  public function get_local_data_back_post()
  {
      $data=$this->basic->get_file_content();
        $final_result=array();
        foreach ($data as $row)
        {
            $where['where'] = array('{PRE}product_details.product_id' => $row['product_id'],'{PRE}product_details.is_deleted'=>0);
            $join = array("{PRE}unit_product_mapping" => "{PRE}unit_of_product.unit_product_id = {PRE}unit_product_mapping.unit_id,inner");
            $result['product_details'] = $this->basic->get_data('{PRE}product_details',$where,'{PRE}product_details.*');
            $where['where'] = array('{PRE}unit_product_mapping.product_id'=>$row['product_id']);
            $result['unit_details'] = $this->basic->get_data('{PRE}unit_of_product',$where,'{PRE}unit_of_product.*,{PRE}unit_product_mapping.*',$join);
            array_push($final_result,$result);
        }
      $this->create_message($final_result);
  }
  public function verify_order_post(){
      $data = $this->basic->get_file_content();
      $id = $data['order_id'];
      foreach(json_decode($data['order_details'],true) as $temp){
           $where = array('order_id'=>$data['order_id'],'product_id'=>$temp);
           $this->basic->update_data('{PRE}order_products',$where,array('is_verified'=>1));
      }
      $where = array('id'=>$data['order_id']);
      $this->basic->update_data('{PRE}orders',$where,array('status'=>2,'order_status'=>'Out for Delivery'));
      $where['where'] = array('order_id'=>$id);
      $temp3['order_id'] = $id;
      $temp2 = $this->basic->get_data('{PRE}payments',$where,'invoice_id,order_id','','','','payment_id desc');
      if(!empty($temp2[0]->order_id)){
        $temp3['invoice_id'] = $temp2[0]->invoice_id;
        $where = array('order_id'=>$temp2[0]->order_id); 
        $this->basic->delete_data('{PRE}payments',$where);
      }else{
          $temp3['invoice_id'] = 1;
      }
      $where['where'] = array('is_verified'=>1,'order_id'=>$id);
      $temp2 = $this->basic->get_data('{PRE}order_products',$where,'SUM(total_price) as amount');
      $temp3['amount'] = $temp2[0]->amount;
      $temp3['due_date'] = date('Y-m-d',strtotime('+1 month',strtotime(date('Y-m-d'))));
      $result = $this->basic->insert_data('{PRE}payments',$temp3);
      // $invoice_id = $this->basic->generate_invoice($id);
      //  $join = array('{PRE}orders'=>'{PRE}orders.user_id = {PRE}users.user_id,inner');
      //  $where['where'] = array('order_id'=>$id);
      //  $data = array();
      //  $data = $this->basic->get_data('{PRE}users',array('id'=>$id),'*',$join);
      //  $link = base_url().'assets/pdfs/invoice/INV-000'.$invoice_id.".pdf";
      //  $this->basic->update_data('{PRE}payments',$where['where'],array('invoice_link'=>$link));
      //  $this->basic->update_data('{PRE}invoice',array('id'=>$invoice_id),array('invoice_link'=>$link));
      //  $result = $this->basic->update_data('{PRE}orders',array('id'=>$id),array('link'=>$link));
      //       $data['message'] = "Your Invoice is Generated Check it Here.";
      //        $data['first_name'] = $data[0]->first_name;
      //         $data['last_name'] = $data[0]->last_name;
      //          $data['device_id'] = $data[0]->player_id;
      //           $data['link'] = $link;
      //            create_notification($data);
             $this->create_message($result);
  }
  
  public function get_updated_orders_post(){
      $data = $this->basic->get_file_content();
      $where['where'] = array('order_id'=>$data['order_id']);
      $result = $this->basic->get_data('update_order_history',$where,'*');
      $this->create_message($result);
  }

  public function get_shipping_addresses_post(){
   $data = $this->basic->get_file_content();
    $where['where'] = array('user_id'=>$data['user_id']);
    $result = $this->basic->get_data('{PRE}shipping_addresses',$where,'*');
     $this->create_message($result);
  }

  public function store_shipping_address_post(){
    $data = $this->basic->get_file_content();
     $where = array('postal_code'=>$data['shipping_zip']);
     $check = $this->basic->is_exist('{PRE}city',$where,'postal_code');
     if(!empty($check)){
            $result = $this->basic->insert_data('{PRE}shipping_addresses',$data);
     }
     else{
         $result = 0;
     }
    $this->create_message($result);
  }

  public function get_order_whole_details_post(){
    $data = $this->basic->get_file_content();
    $data['order_details'] = $this->basic->get_data("{PRE}order_products",array('where'=>array('order_id'=>$data['order_id'])),'product_id');
      foreach($data['order_details'] as $index=>$temp){
      $where['where'] = array('{PRE}product_details.product_id' => $temp->product_id,'{PRE}product_details.is_deleted'=>0,'order_id'=>$data['order_id']);
      $join = array('{PRE}order_products'=>'{PRE}product_details.product_id = {PRE}order_products.product_id,inner');
      $result[$index]['product_details'] = $this->basic->get_data('{PRE}product_details',$where,'{PRE}product_details.*,{PRE}order_products.quantity',$join);
      $where['where'] = array('{PRE}unit_product_mapping.product_id'=>$temp->product_id);
      $join = array("unit_product_mapping" => "{PRE}unit_of_product.unit_product_id = {PRE}unit_product_mapping.unit_id,inner");
      $result[$index]['unit_details'] = $this->basic->get_data('{PRE}unit_of_product',$where,'{PRE}unit_of_product.*,{PRE}unit_product_mapping.*',$join);
      }
      $this->create_message($result);
  }
 }
?>