<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
         Add Product Details
      </h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class=""></i>Home</a></li>
         <li><a href="<?php echo base_url(); ?>Home_ctrl/view_product">Product Details</a></li>
         <li class="active">Add Product</li>
      </ol>
   </section>
   <!-- Main content -->
   <section class="content">
      <div class="row">
         <!-- left column -->
         <div class="col-md-12">
            <?php
               if($this->session->flashdata('message')) {
               $message = $this->session->flashdata('message');
               ?>
            <div class="alert alert-<?php echo $message['class']; ?>">
               <button class="close" data-dismiss="alert" type="button">×</button>
               <?php echo $message['message']; ?>
            </div>
            <?php
               }
               ?>
         </div>
         <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-warning">
               <div class="box-header with-border">
                  <h3 class="box-title">Product Details</h3>
               </div>
               <!-- /.box-header -->
               <!-- form start -->
			    <form role="form" action="" id="my_form" method="post" data-parsley-validate="" enctype="multipart/form-data">

                  <div class="box-body">
                     <div class="col-md-6">
					  
					  <div class="form-group ">
									<label class="control-label" for="shopimage">Select Images (Image Size should be 200x200)</label>
									<input type="file" class="form-control" name="image" size="20" />
                                    </div>
									<div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Product Name</label>
                            <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  data-parsley-pattern="^[a-zA-Z0-9.,()\  \-\/]+$" required="" name="product_name"  placeholder="Product Name">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div>
                        
                        	<div class="form-group">
                          <label>CGST + SGST</label>
                           <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  data-parsley-pattern="^[0-9.,\  \/]+$" required="" id="total_tax" name="total_tax" placeholder="Enter Tax">
                      </div>
                       <div class="form-group has-feedback" id="input_tax">
                           <label for="exampleInputEmail1">Enter Tax Rate</label>
                            <input type="text" class="form-control" id="rate"  placeholder="Enter Price">
                            <div class="box-footer">
                                <button type="button" id="add1" class="btn btn-primary" >ADD</button>
                            </div> 
                       </div>
                      <div class="form-group">
                         Inclusive <input type="radio" id="Check1" name="is_inclusive" value="0" onclick="selectOnlyThis(this.id)" /> 
                         Exclusive <input type="radio" id="Check2" name="is_inclusive" value="1" onclick="selectOnlyThis(this.id)" /> 
                      </div>
						<div class="form-group">
                          <label>Unit</label>
                          <select class="form-control select2" style="width: 100%;" id="unit" >
                          <option value=''>Select</option>
                   <?php
                  foreach($unit as $units){
                   
                   ?>

                   <option value="<?php echo $units->unit_product_id.'&'.$units->unit;?>"><?php echo $units->unit;?></option>
                      <?php
                   }
                   ?> 
                          </select>
                          </div>  
                         
                           <div class="form-group has-feedback" id="input_quatity">
                           <label for="exampleInputEmail1">Sales Price Per Unit</label>
                            <input type="text" class="form-control" id="quantity"  placeholder="Enter Price">
                             <label for="exampleInputEmail1">Purchase Price Per Unit</label>
                            <input type="text" class="form-control" id="purchase_price"  placeholder="Enter Price">
                           <label for="exampleInputEmail1">Weight</label>
                            <input type="text" class="form-control" id="weight"  placeholder="Enter Weight">
                             <label for="exampleInputEmail1">Max Quantity</label>
                            <input type="text" class="form-control" id="max_quantity"  placeholder="Enter quantity">
                            <div class="box-footer">
                     <button type="button" id="add" class="btn btn-primary" >ADD</button>
                  </div>    
                        </div>
						<div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Details</label>
                            <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  required="" name="details"  placeholder="Product Description">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div>
                       <!--  
						<div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Ingredients</label>
                            <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  data-parsley-pattern="^[a-zA-Z0-9.,()\  \/]+$" required=""  name="ingredients"  placeholder="Ingredients">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div> 
						<div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Warnings</label>
                            <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  data-parsley-pattern="^[a-zA-Z0-9.,()\  \/]+$" required="" name="warnings"  placeholder="Warnings">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div> 
						<div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Directives</label>
                            <input type="text" class="form-control required" data-parsley-trigger="change"	
                            data-parsley-minlength="2"  data-parsley-pattern="^[a-zA-Z0-9.,()\  \/]+$" required="" name="directives"  placeholder="Directives">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div>--> 					
			<!-- 	 <div class="form-group">
                          <label>Select Discount Code</label>
							<select class="form-control select2 required"  style="width: 100%;" id="discount_code" name="discount_amount" onchange="updateInput()">
							<option value="0">select</option>
								   <?php
									  foreach($discount as $discount_codevalue){
								   ?>
								   <option value="<?php echo $discount_codevalue->discount_amount;?>"><?php echo $discount_codevalue->discount_code;?></option>
								   <?php
								   }
								   ?>
                            </select> 
                      </div>
					  <div class="form-group has-feedback">
                           <label for="exampleInputEmail1">Final Price</label>
                            <input type="text" class="form-control" name="final_price"  placeholder="Final Price">
                           <span class="glyphicon  form-control-feedback"></span>
                        </div>  -->
                      
					    <div class="box-footer">
                     <button type="submit" class="btn btn-primary">Submit</button>
                  </div>             
                        </div>   
                          <input type="hidden" name="option_count" id="option_count" value="<?php if(isset($item_options) && count($item_options)>0) echo count($item_options)+1; else echo "1";?>">
				    <input type="hidden" name="option_counts" id="option_counts">
                        <div class="col-md-6">
                          <table class="table table-bordered" id="first">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Unit</th>
                           <th>Sales Price</th>
                            <th>Purchase Price</th>
                             <th>Weight</th>
                              <th>Max Quantity</th>
                        </tr>
                      </thead>
                      <tbody>
                          
                          </tbody>
                            </table>
                        </div>
                        <hr>
        <!--                 <input type="hidden" name="option_count1" id="option_count1" value="<?php if(isset($item_options) && count($item_options)>0) echo count($item_options)+1; else echo "1";?>">-->
				    <!--<input type="hidden" name="option_counts1" id="option_counts1">-->
        <!--                <div class="col-md-4">-->
        <!--                  <table class="table table-bordered" id="first1">-->
        <!--              <thead>-->
        <!--                <tr>-->
        <!--                  <th>#</th>-->
        <!--                  <th>Unit</th>-->
        <!--                   <th>Price</th>-->
        <!--                </tr>-->
        <!--              </thead>-->
        <!--              <tbody>-->
                          
        <!--                  </tbody>-->
        <!--                    </table>-->
        <!--                </div>-->
            
               </form>
            </div>
			<script>
		     $('#input_quatity').hide();
			  $('#input_tax').hide();
			  $('#my_form').on('submit',function(){
			       var unit = $('#option_count').val();
			      if(unit == 1){
			          alertify.error("Please Select Unit First");
			          return false;
			      }
			    })
			$(document).ready(function(){
			  var check_array =[];
			    $('#unit').on('change',function(){
			         $('#input_quatity').show();
			    });
			    $('#add').on('click',function(){
			        var select = $('#unit').val().split('&');
			        var price = $('#quantity').val();
			        var purchase_price = $('#purchase_price').val();
			         var weight = $('#weight').val();
			          var max_quantity = $('#max_quantity').val();
			        if(select[0] ==''){
			            alertify.error("Please Select Valid Option");
			        }
			        else if(price == ''){
			            alertify.error("Please Enter Valid Quantity");
			        }
			        else if(in_array(select[0],check_array)){
  	                    alertify.error("Already Exist");
                    }else{
                    check_array.push(select[0]);
			       var cnt=$("#option_count").val();
  	   var ncnt = cnt;
  	   var sno = cnt;
  		
  	   $('#first tr').last().after('<tr style="background-color:#4a4f56;"><th scope="row" style="color:white">'+sno+'</th><td><input style="width:40px;background-color:#e7e7e7;text-align:center" type="text" readonly name="option_name'+ncnt+'" id="option_name'+ncnt+'" value="'+select[1]+'"></td><td><input type="hidden" readonly value="'+select[0]+'" name="option_id'+ncnt+'" id="option_id'+ncnt+'"><input style="width:70px;background-color:#e7e7e7;text-align:center;" type="text" value="'+price+'" name="price'+ncnt+'" id="price'+ncnt+'"></td><td><input style="width:70px;background-color:#e7e7e7;text-align:center;" type="text" value="'+purchase_price+'" name="purchase_price'+ncnt+'" id="purchase_price'+ncnt+'"></td><td><input style="width:70px;background-color:#e7e7e7;text-align:center;" type="text" value="'+weight+'" name="weight'+ncnt+'" id="weight'+ncnt+'"></td><td><input style="width:70px;background-color:#e7e7e7;text-align:center;" type="text" value="'+max_quantity+'" name="max_quantity'+ncnt+'" id="max_quantity'+ncnt+'"></td></tr>');
  		
  		cnt=++cnt;
  	   $("#option_count").val(cnt);
  	   $("#option_counts").val(cnt);
			        $('#unit').prop('selectedIndex',0);
			       $('#quantity').val('');
			       $('#weight').val('');
			        $('#max_quantity').val('');
                    }
			    })
			})
		
 $('#tax_id').on('change',function(){
			         $('#input_tax').show();
			    });
			    var check_array1 =[];
			    $('#add1').on('click',function(){
			        var tax_id = $('#tax_id').val();
			        var rate = $('#rate').val();
			        if(tax_id ==''){
			            alertify.error("Please Select Valid Option");
			        }
			        else if(rate == ''){
			            alertify.error("Please Enter Valid Quantity");
			        }
			        else if(in_array1(tax_id,check_array1)){
  	                    alertify.error("Already Exist");
                    }else{
                    check_array1.push(tax_id);
			       var cnt1=$("#option_count").val();
  	                var ncnt1 = cnt1;
  	                 var sno1 = cnt1;
  		
  	   $('#first1 tr').last().after('<tr style="background-color:#4a4f56;"><th scope="row" style="color:white">'+sno1+'</th><td><input style="width:20px;background-color:#e7e7e7;text-align:center" type="text" readonly name="tax_id'+ncnt1+'" id="tax_id'+ncnt1+'" value="'+tax_id+'"></td><td><input style="width:20px;"readonly value="'+rate+'" name="rate'+ncnt1+'" id="rate'+ncnt1+'"></td></tr>');
  		
  		cnt1=++cnt1;
  	   $("#option_count1").val(cnt1);
  	   $("#option_counts1").val(cnt1);
			        $('#tax_id').val('');
			       $('#rate').val('');
                    }
			    })
			    
			function in_array(search, array)
  {
	  for (i = 0; i < array.length; i++)
	  {
		if(array[i] ==search )
		{
			return true;
		}
	  }
	  return false;
  }
  function in_array1(search, array)
  {
	  for (i = 0; i < array.length; i++)
	  {
		if(array[i] ==search )
		{
			return true;
		}
	  }
	  return false;
  }
</script>
            <!-- /.box -->
         </div>
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
</div>

