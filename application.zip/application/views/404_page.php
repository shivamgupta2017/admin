<!DOCTYPE html>
<html lang="en">
   <head>
            <meta charset="utf-8">

      <meta http-equiv="X-UA-Compatible" content="IE=edge">

      <meta name="viewport" content="width=device-width, initial-scale=1">

      <meta name="description" content="">

      <meta name="author" content="">

      <link rel="icon" href="http://192.168.138.31/Jaise/click_kart/assets/images/favicon.ico">

      <title>clickkart</title>

      <!-- Bootstrap Core CSS -->

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/bootstrap.min.css" rel="stylesheet">

      <!-- Custom CSS -->

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/landing-page.css" rel="stylesheet">

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/animations.css" rel="stylesheet">

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/animate.css" rel="stylesheet">

      <!-- Owl Carousel Assets -->

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/owl.theme.css" rel="stylesheet">

      <link href="http://192.168.138.31/Jaise/click_kart/assets/css/owl.carousel.css" rel="stylesheet">

      <!-- Custom Fonts -->

      <link href="http://192.168.138.31/Jaise/click_kart/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

      <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700' rel='stylesheet' type='text/css'>

        <link href="http://192.168.138.31/Jaise/click_kart/assets/css/parsley/parsley.css" rel="stylesheet" type="text/css">
   </head>
   <body>
      <div class="landing_bg">
         
         <div class="landing_zip_blck error_pge">
            <div class="container">
               <div class="row">
                  <div class="col-md-3"></div>
                  <div class="col-md-6">
                      
                     <!-- login-->
                      
                     <div id="land_log1" class="zip_block login_find find_div not_pag clr_gray" >
                        <img class="not_fnd" src="<?php echo base_url()?>assets/images/404.png">
                        
                     </div>
                      
                    <!-- login-end-->
                   
                     <div class="footer_list">
                        <ul>
                           <li><a>Help</a></li>
                           <li><a>Contact</a></li>
                           <li><a>Press</a></li>
                           <li><a>privacy</a></li>
                           <li><a>Terms</a></li>
                           <li><a>Become a Shopper</a></li>
                        </ul>
                     </div>
                      
                  </div>
                  <div class="col-md-3"></div>
               </div>
            </div>
         </div>
      </div>
       
      <!-- jQuery -->
      <!-- Bootstrap Core JavaScript -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/custom.js"></script>
      <script src="js/owl.carousel.js"></script>
      <script src="js/css3-animate-it.js"></script>
      <script src="js/jquery.fullscreen-popup.js"></script>
       <script src="js/zoomIn.js"></script>
   </body>
</html>

